//Zachary Talarick
//I pledge my honor that I have abided by the Stevens Honor System.

#ifndef __LOG_H__
#define __LOG_H__

void my_log(char* input);

#endif
