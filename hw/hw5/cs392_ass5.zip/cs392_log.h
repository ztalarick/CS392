//Zachary Talarick
//I pledge my honor that I have abided by the Stevens Honor System.

#ifndef __LOG_H__
#define __LOG_H__

void cs392_socket_log(char * ip, char * port);

#endif


