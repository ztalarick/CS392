//Zachary Talarick
//I pledge my honor that I have abided by the Stevens Honor System.

#ifndef __EXEC_H__
#define __EXEC_H__

char** parse(char * str);
void execute(char *command);

#endif
