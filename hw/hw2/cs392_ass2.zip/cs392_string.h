//I pledge my honor that I have abided by the Stevens Honor System.

#ifndef cs392_STRING_H_
#define cs392_STRING_H_

void * cs392_memcpy ( void * dst, void * src, unsigned num);

unsigned cs392_strlen(char *str);

#endif //cs392_STRING_H_
